Corrector Ortográfico

Construcción:

    $ make program

Corrección sin chequear duplicados:

    $ ./main archivoDiccionario archivoSalida

Corrección chequeando duplicados:

    $ ./main archivoDiccionario archivoSalida -cd