#include "tablahash.h"
#include "../words.h"
#include "glist.h"
#include <assert.h>
#include <stdlib.h>

/**
 * Casillas en la que almacenaremos los datos de la tabla hash.
 */
typedef GList HashBox;



HashTable hashtable_make(unsigned size, CopyFunction copy,
                          CompareFunction comp, DestroyFunction destr,
                          HashFunction hash) {

  // Pedimos memoria para la estructura principal y las casillas.
  HashTable table = malloc(sizeof(struct _HashTable));
  assert(table != NULL);
  table->elems = malloc(sizeof(HashBox) * size);
  assert(table->elems != NULL);
  table->numElems = 0;
  table->size = size;
  table->copy = copy;
  table->comp = comp;
  table->destr = destr;
  table->hash = hash;

  // Inicializamos las casillas con datos nulos.
  for (unsigned idx = 0; idx < size; ++idx) {
    table->elems[idx] = glist_make();
  }

  return table;
}


int hashtable_nelems(HashTable table) { return table->numElems; }


int hashtable_size(HashTable table) { return table->size; }


HashBox hashtable_elem(HashTable table, unsigned n) 
{
  if (n >= table->size)
    return NULL;
  else 
    return table->elems[n];
}


void hashtable_destroy(HashTable table) {

  // Destruir cada uno de los datos.
  for (unsigned idx = 0; idx < table->size; ++idx)
    if (!glist_empty(table->elems[idx]))
      glist_destroy(table->elems[idx], table->destr);

  // Liberar el arreglo de casillas y la tabla.
  free(table->elems);
  free(table);
  return;
}


float charge_factor(HashTable table)
{
  return ((float)hashtable_nelems(table) / (float)hashtable_size(table)); 
}
  

void hashtable_insert(HashTable table, void *data) {

  
  // Redimensiono en caso de superar el factor de carga.
  if (charge_factor(table) > CHARGE_FACTOR_MAX)
    hashtable_resize(table);


  // Calculamos la posicion del dato dado, de acuerdo a la funcion hash.
  unsigned idx = table->hash(data) % table->size;

  // Insertar el dato si la casilla estaba libre.
  if (!glist_search(table->elems[idx], data, table->comp)) {
    table->numElems++;
    table->elems[idx] = glist_add_end(table->elems[idx], data, table->copy);
    return;
  }
  //No hacer nada en caso de que el dato este en la casilla.
}


int hashtable_search(HashTable table, void *data) {

  // Calculamos la posicion del dato dado, de acuerdo a la funcion hash.
  unsigned idx = table->hash(data) % table->size;

  // Retornamos 1 o 0 dependiendo de la busqueda(glist_search).
  return glist_search(table->elems[idx], data, table->comp);

}


void hashtable_remove(HashTable table, void *data) {

  // Calculamos la posicion del dato dado, de acuerdo a la funcion hash.
  unsigned idx = table->hash(data) % table->size;

  //Descontar 1 al numero de elementos ya que uno sera eliminado.
  if (glist_remove(table->elems[idx], data, table->comp, table->destr))
    table->numElems--;
  
  //Eliminar el elemento si se encuentra en la table.
  table->elems[idx] = glist_remove(table->elems[idx], data, table->comp, table->destr);
}


void hashtable_resize(HashTable table) {
 
  GList *temp_elems = table->elems;
  int temp_cap = table->size;
  table->size *= 2;
  table->numElems = 0;
  table->elems = malloc(sizeof(GList) * table->size);
  assert(table->elems != NULL);
  
  // Inicializamos las casillas con datos nulos.
  for (unsigned i = 0; i < table->size; i++) 
    table->elems[i] = glist_make();
  
  for (int i = 0; i < temp_cap; i++) {
    GList temp = temp_elems[i];
    for (; temp != NULL; temp = temp->next)
      hashtable_insert(table, temp->data);
    glist_destroy(temp_elems[i], table->destr);
  }

  free(temp_elems);
  
}
